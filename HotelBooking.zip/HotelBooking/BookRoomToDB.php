<?php

$target_path = "uploads/";
$response = array();
$server_ip = gethostbyname(gethostname());

$file_upload_url = 'http://' . $server_ip . '/' . 'HotelBooking' . '/' . $target_path;

if (isset($_FILES['image']['name'])) {
    $target_path = $target_path . basename($_FILES['image']['name']);

    // reading other post parameters
    $filename = basename($_FILES['image']['name']);
    $filePath = $file_upload_url . '' . $filename;

    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $nocandidate = isset($_POST['nocandidate']) ? $_POST['nocandidate'] : '';
    $nostay = isset($_POST['nostay']) ? $_POST['nostay'] : '';
    $fromplace = isset($_POST['fromplace']) ? $_POST['fromplace'] : '';

    try {
        // Throws exception incase file is not being moved
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            // make error flag true
            $response['error'] = true;
            $response['message'] = 'Could not move the file!';
        }
        // File successfully uploaded
        $response['message'] = 'File uploaded successfully!';
        $response['error'] = false;
        $response['file_path'] = $file_upload_url . basename($_FILES['image']['name']);
    } catch (Exception $e) {
        // Exception occurred. Make error flag true
        $response['error'] = true;
        $response['message'] = $e->getMessage();
    }

    $db_host = "localhost";
    $db_uid = "root";
    $db_pass = "123";
    $db_name = "hotelbooking";


    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $nocandidate = isset($_POST['nocandidate']) ? $_POST['nocandidate'] : '';
    $nostay = isset($_POST['nostay']) ? $_POST['nostay'] : '';
    $fromplace = isset($_POST['fromplace']) ? $_POST['fromplace'] : '';
    $fromdate = isset($_POST['fromdate']) ? $_POST['fromdate'] : '';
    $todate = isset($_POST['todate']) ? $_POST['todate'] : '';


    $db_con = mysql_connect($db_host, $db_uid, $db_pass) or die('Unable to Connect to Database');
    mysql_select_db($db_name);


    
    
    $sql = "insert into hotel(name, email, phone, nocandidates, nostay, fromplace, filename, fromdate, todate) values 
    ('$name','$email','$phone','$nocandidate','$nostay','$fromplace','$filename','$fromdate','$todate')";
    
    $result = mysql_query($sql);

    if ($result == "1") {
        echo "Success";
    } else {
        echo "Fail";
    }
    mysql_close();
} else {
    // File parameter is missing
    $response['error'] = true;
    $response['message'] = 'Not received any file!F';
}

// Echo final json response to client

echo json_encode($response);

header("Location: success.php");
?>