<!DOCTYPE HTML>
<html>
    <head>
        <title>Hotel Booking : Gallary</title>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-1.11.0.min.js"></script>
        <!-- Custom Theme files -->
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
        <link href="css/style1.css" rel="stylesheet" type="text/css" media="all" />	
        <!-- Custom Theme files -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Mr Hotel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
              Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        <!--Google Fonts-->
        <link href='//fonts.googleapis.com/css?family=Hind:400,300' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Aladin' rel='stylesheet' type='text/css'>
        <!--google fonts-->
        <!-- animated-css -->
        <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
        <script src="js/wow.min.js"></script>
        <script>
            new WOW().init();
        </script>
        <!-- animated-css -->
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body>
        <!--header-top start here-->
        <div class="top-header">
            <div class="container">
                <div class="top-header-main">
                    <div class="col-md-4 top-social wow bounceInLeft" data-wow-delay="0.3s">
                        
                    </div>
                    <div class="col-md-8 header-address wow bounceInRight" data-wow-delay="0.3s">
                        <ul>
                            
                        </ul>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        <!--header-top end here-->
        <!--header start here-->
        <!-- NAVBAR
                ================================================== -->
        <div class="header">
            <div class="fixed-header">	
                <div class="navbar-wrapper">
                    <div class="container">
                        <nav class="navbar navbar-inverse navbar-static-top">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div class="logo wow slideInLeft" data-wow-delay="0.3s">
                                    <a class="navbar-brand" href="index.php"><img src="images/logo.png" /></a>
                                </div>
                            </div>
                            <div id="navbar" class="navbar-collapse collapse">
                                <nav class="cl-effect-16" id="cl-effect-16">
                                    <ul class="nav navbar-nav">
                                        <li><a href="index.php" data-hover="Home">Home</a></li>
                                        <li><a href="admin.php" data-hover="Admin">Admin</a></li>
                                        <li><a href="rooms.php" data-hover="Rooms">Rooms</a></li>
                                        <li><a href="bookcab.php" data-hover="Book Cab">Book Cab</a></li>
                                        <li><a class ="active" href="gallery.php" data-hover="Gallery">Gallery</a></li>
                                        <li><a href="contact.php" data-hover="Contact">Contact</a></li>															
                                    </ul>
                                </nav>

                            </div>
                            <div class="clearfix"> </div>
                        </nav>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        <!--header end here-->
        <!--services strat here-->
        <div class="services">
            <div class="container">
                <div class="services-man">
                    <div class="services-top">
                        <h1>Gallery</h1>				
                    </div>
                    <div class="services-bottom wow slideInLeft" data-wow-delay="0.3s">
                        <div class="col-md-4 services-grid">				
                            <div class="item item-type-move">
                                <a class="item-hover" href="moreGallery.php">						
                                    <div class="item-info">
                                        <div class="headline">
                                            Our Rooms
                                            <div class="line"> </div>
                                        </div>
                                        		
                                    </div>
                                    <div class="mask"> </div>
                                </a>
                                <div class="item-img">
                                    <img src="images/s1.jpg" class="img-responsive" alt="">
                                </div>
                            </div>
                            <div class="clearfix"> </div>
                            <div class="ser-text">
                                
                            </div>
                        </div>
                        <div class="col-md-4 services-grid">				
                            <div class="item item-type-move">
                                <a class="item-hover" href="moreGallery.php">						
                                    <div class="item-info">
                                        <div class="headline">
                                            Our Rooms
                                            <div class="line"> </div>
                                        </div>
                                
                                    </div>
                                    <div class="mask"> </div>
                                </a>
                                <div class="item-img">
                                    <img src="images/s2.jpg" class="img-responsive" alt="">
                                </div>
                            </div>
                            <div class="clearfix"> </div>
                            <div class="ser-text">
                                
                            </div>
                        </div>
                        <div class="col-md-4 services-grid">
                            <div class="item item-type-move">
                                <a class="item-hover" href="moreGallery.php">						
                                    <div class="item-info">
                                        <div class="headline">
                                            Our Rooms
                                            <div class="line"> </div>
                                        </div>
                                
                                    </div>
                                    <div class="mask"> </div>
                                </a>
                                <div class="item-img">
                                    <img src="images/s3.jpg" class="img-responsive" alt="">
                                </div>
                            </div>
                            <div class="clearfix"> </div>
                            <div class="ser-text">
                                
                            </div>
                        </div>			
                        <div class="clearfix"> </div>
                    </div>
                </div>
            </div>
        </div>
        <!--services end here-->
        <!--services strip start here-->
        <div class="ser-strip">
            <div class="container">
                <div class="ser-strip-main wow rollIn" data-wow-delay="0.3s">
                    <h2>Our Interior</h2>
                    <p></p>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
        <!--services strip end here-->
        <!--features strat here-->
        

        <!--features end here-->
        <!--footer start here-->
        <div class="footer">
            <div class="container">
                
            </div>
        </div>
        <!--footer end here-->
        <!--copy rights start here-->
        <div class="copy-right">
            <div class="container">
                <div class="copy-rights-main wow zoomIn" data-wow-delay="0.3s">
                    <p>© 2017 All Rights Reserved</p>
                </div>
            </div>
        </div>
    </body>
</html>