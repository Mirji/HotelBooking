<?php


    $db_host = "localhost";
    $db_uid = "root";
    $db_pass = "123";
    $db_name = "hotelbooking";


    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $nopeople = isset($_POST['nopeople']) ? $_POST['nopeople'] : '';
    $fromplace = isset($_POST['fromplace']) ? $_POST['fromplace'] : '';
    $toplace = isset($_POST['toplace']) ? $_POST['toplace'] : '';


    $db_con = mysql_connect($db_host, $db_uid, $db_pass) or die('Unable to Connect to Database');
    mysql_select_db($db_name);


    $sql = "insert into cab(name, email, phone, nopeople, fromplace, toplace) values 
    ('$name','$email','$phone','$nopeople','$fromplace','$toplace')";
    $result = mysql_query($sql);

    if ($result == "1") {
        //echo "Success";
		header("Location: success.php");
		
    } else {
        header("Location: fail.php");
    }
    mysql_close();

header('Location: index.php');
?>