<?php

error_reporting(E_ERROR);

$db_host = "localhost";
$db_uid = "root";
$db_pass = "123";
$db_name = "hotelbooking";

$db_con = mysql_connect($db_host, $db_uid, $db_pass) or die('Unable to Connect to Database');

mysql_select_db($db_name);

$adminid = $_POST['adminid'];

$password = $_POST['password'];


$sql = "select * from admin where adminid ='$adminid' and password = '$password'";

$result = mysql_query($sql);

$row = mysql_num_rows($result);

//echo $row['username'];

if ($row == 1) {
    header('Location: adminPage.php');
} else {
    header('Location: error.php');
}
mysql_close();
?>